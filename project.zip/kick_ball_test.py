import numpy as np
from ai_agents.v2.gym.full_information_protagonist_antagonist_gym import FoosballEnv
import mujoco

def main():
    env = FoosballEnv(antagonist_model=None, play_until_goal=False, verbose_mode=True)
    obs, info = env.reset()

    # IMPORTANT: kick immediately after reset
    env._reset_ball_to_center()
    env._kick_ball_x(vx=2.0)
    ball_pos, ball_vel = env._get_ball_obs()
    print("[KICK TEST] after _kick_ball_x, ball_pos=", ball_pos, "ball_vel=", ball_vel)
    # env._debug_ball_dofs()
    env._debug_ball_geoms()

    for t in range(1, 101):
        action = np.zeros(env.protagonist_action_size, dtype=np.float64)
        obs, reward, terminated, truncated, info = env.step(action)

        ball_pos, ball_vel = env._get_ball_obs()
        print(
            f"t={t:03d}  pos=({ball_pos[0]: .3f}, {ball_pos[1]: .3f})  "
            f"vel=({ball_vel[0]: .3f}, {ball_vel[1]: .3f})"
        )


    env.close()

if __name__ == "__main__":
    main()
